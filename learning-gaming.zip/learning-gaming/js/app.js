$(document).ready(function(){
    $("#info-panel-btn-1").on("click",function(){
        $("#info-panel-1").toggleClass("show");
    });
    $(function () {
        $('[data-toggle="popover"]').popover()
    })
});